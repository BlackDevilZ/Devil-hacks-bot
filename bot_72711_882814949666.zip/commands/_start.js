/*CMD
  command: /start
  help: 
  need_reply: true
  auto_retry_time: 
  folder: 

  <<ANSWER
Sup My Homie?! 

Bitch its me D3V1L, Don't Spam Bot Gayyy! I Will Reply As Soon As Possible

With Love @devil_hacks ❤️
  ANSWER
  keyboard: 
  aliases: 
CMD*/

